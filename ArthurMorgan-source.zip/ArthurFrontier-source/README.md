# 亚瑟 · 荒野死神 8.0

可离线运行的 Windows 独立桌面小游戏。2.5D 西部小镇、骑马进镇、五波敌人、无限死神之眼，以及六发左轮和八发长枪。

## 构建与运行

1. 将整个源码包解压到同一个文件夹。
2. 双击 `build.cmd`，或在该目录的终端运行 `build.cmd`。
3. 启动生成的 `bin\ArthurFrontier.exe`。

构建脚本使用 Windows 随附的 .NET Framework C# 编译器，不需要 Node.js、浏览器、NuGet 包或联网下载。推荐 Windows 10 1803 及以上版本；也提供 `ArthurFrontier.csproj`，可用带 .NET Framework 4.8 开发工具的 Visual Studio 打开。

## 操作与伤害规则

| 按键 | 动作 |
|---|---|
| WASD | 移动／骑马 |
| 鼠标左键 | 射击 |
| 1 | 六发左轮 |
| 2 | 八发长枪（开局默认） |
| R | 手动换弹 |
| E | 无限开启／关闭死神之眼 |
| F | 抵达日落镇后上马／下马 |
| 空格 | 徒步闪避／骑马冲刺 |
| ESC | 暂停／继续 |
| F3 | 显示实际帧率与显示后端 |
| F11 | 全屏／窗口 |

长枪每发伤害 100，第一关普通敌人生命值为 70～80，因此命中一枪击败。最终首领生命值为 1000，长枪需要命中 10 枪；开启死眼不会提高长枪伤害。长枪只有八发弹匣，打首领需要至少换弹一次。左轮保留原有伤害和较快射速，两把武器分别保存剩余子弹，切枪会取消正在进行的换弹。

武器数值集中在 `src/Game/Weapons.cs`，普通敌人及首领生成在 `src/Game/FrontierGame.cs`。

## 源码结构

```text
src/
  Program.cs                    程序入口与诊断命令
  Properties/AssemblyInfo.cs     版本信息
  Game/
    Entities.cs                 角色、子弹、建筑等数据
    FrontierGame.cs              游戏状态、移动、碰撞、波次及输入
    Weapons.cs                  弹匣、伤害与首领规则
  Rendering/
    SceneRenderer.cs            2.5D 投影、地图、动画缓存与界面
    GameRenderer.cs             固定尺寸帧缓冲和 GDI 兼容输出
    GpuPresenter.cs             OpenGL 加速上传、缩放和死眼着色
  Platform/
    FrontierWindow.cs           Windows 窗口、输入及整帧调度
    FrameClock.cs               高精度等待计时器
tests/
  SelfTest.cs                   玩法回归及画面输出
  FrameProbe.cs                 原生窗口帧循环测试
assets/
  frontier.ico                 程序图标
  app.manifest                 DPI 与普通用户权限声明
build.cmd / build.rsp           无外部依赖的构建入口
ArthurFrontier.csproj           Visual Studio 项目
```

图形通过代码生成；程序图标、游戏逻辑、音效生成逻辑均包含在源码中。运行时不依赖额外图片、音频文件或后台服务。

## 性能设计

- 地图斜投影、建筑及角色动画预先缓存，屏幕外的对象跳过绘制。
- 内部画面保持 1280×800，通过显卡缩放到窗口／全屏尺寸，避免 Retina 分辨率下重复进行 CPU 大图复制。
- 使用持久帧缓冲，复用文字、画笔及画刷，缓存设有上限。
- 用高精度等待计时器和单个待处理帧请求替代线程池周期计时，避免约 32 FPS 的调度限制。
- 支持的显卡使用 OpenGL 呈现，并由 GPU 完成死眼全屏着色。无法创建加速上下文时尝试兼容 GDI 输出。
- 目标为约 60 FPS；暂停时降低刷新频率，失去焦点时暂停游戏。

`docs/` 内附本次测试结果。隐藏窗口测试涵盖游戏逻辑、UI 线程调度、绘图和 GPU 完成等待，但不等同于所有可见全屏负载下的帧率保证。实际游玩按 F3 查看帧率。

## 测试

在 PowerShell 中运行，测试会写入指定的文件夹，不修改游戏安装目录：

```powershell
Start-Process -FilePath .\bin\ArthurFrontier.exe -ArgumentList '--self-test test-results\gameplay' -WindowStyle Hidden -Wait
Get-Content .\test-results\gameplay\self-test.txt

Start-Process -FilePath .\bin\ArthurFrontier.exe -ArgumentList '--frame-test test-results\1280' -WindowStyle Hidden -Wait
Get-Content .\test-results\1280\frame-loop.txt

Start-Process -FilePath .\bin\ArthurFrontier.exe -ArgumentList '--frame-test test-results\retina retina' -WindowStyle Hidden -Wait
Get-Content .\test-results\retina\frame-loop.txt
```

玩法测试覆盖普通敌人一枪击败、首领第 10 枪击败（分别开启／关闭死眼）、第九枪前必须换弹，以及骑马、碰撞、暂停、波次和胜负。帧循环测试持续约 12 秒；预热后每秒采样，最低一秒不足 40 FPS 时退出码为 2。

## 实现参考

- [Microsoft：WGL 上下文创建](https://learn.microsoft.com/en-us/windows/win32/api/wingdi/nf-wingdi-wglcreatecontext)
- [Microsoft：高精度等待计时器](https://learn.microsoft.com/en-us/windows/win32/api/synchapi/nf-synchapi-createwaitabletimerexw)

测试程序和生产程序共用同一份游戏与渲染实现，没有额外修改显卡驱动或全局电源设置。

## 5.0 第二关：冷杉矿场
第一关五波通关后，点击进入第二关或按 Enter。第二关保留骑马和无限死眼，采用冷色地面、纵向铁轨、货站和全新掩体布局；每关五波。第二关失败后可直接重试。
第二关小怪固定 160 HP，最终 Boss 麦卡为 1600 HP（小怪十倍）。长枪分别需要命中 2 枪与 16 枪；左轮普通射击间隔为 0.14 秒，死眼中为 0.08 秒。第一关参数保持原样。顶部 Boss 血条实时显示当前 / 最大血量。
第二关隐藏窗口 2880×1753、20 个敌人测试平均 57.0 FPS，最低一秒 55.4 FPS。此结果不保证所有可见窗口场景的最低帧率。
## 6.0 列车、马匹生命与首领回血
第二关每隔 15 秒从铁轨北侧刷新一辆列车，经过后离场；HUD 显示倒计时，暂停时计时冻结。列车撞击会伤害亚瑟、马匹和敌人。
马匹具有独立的 200 HP 和血条。骑乘受击会同时伤害马匹和亚瑟；下马后的马匹可被流弹或列车伤害。马匹倒下后强制下马且无法再次骑乘，本关可继续徒步。进入新关或重试会恢复马匹生命。
两关的大 Boss 连续 5 秒未受伤后，每秒恢复最大生命值的 2%；子弹或列车造成伤害会重置计时，无法超过最大生命，也不会复活。麦卡每秒回复 32 HP。顶部血条同步显示剩余生命与回血状态。
默认本机安装目录：D:\dev\ArthurFrontier。
## 7.0 第三关：列车重机枪 / 20 波与无尽模式
主页可点击三张关卡按钮，也可按 1、2、3 选择后按 Enter 开始，所有关卡均可直接选择。战斗中按 Home 返回主页；暂停、胜负界面也可点击返回主页。
第三关亚瑟固定在列车后部重机枪位，鼠标瞄准、按住左键连续射击，弹药无限、无需换弹。射击间隔 0.075 秒，每发伤害 55；E 保留无限死眼。第三关不使用步行、切枪或上下马。
骑马追兵从车后出现，随着波次增长增加数量、血量和速度，每波最多 24 人。波间恢复亚瑟 12 点生命（不超过 100）。完成第 20 波显示挑战成功，可选择继续无尽模式，从第 21 波继续，或返回选关。失败可重试第三关。
第二关获胜后可进入第三关。前三关互相独立，重试会重置本关状态。
高分辨率 2880×1753 隐藏窗口测试：20 名骑马追兵、重机枪开火，平均 43.2 FPS，最低一秒 40.5 FPS。实际游玩请按 F3 查看帧率。
默认安装位置：D:\dev\ArthurFrontier。
## 8.0 第三关：三人协同与高速参照景物
树木和草丛在轨道两侧持续向后掠过，使用不同滚动速度。树木、草丛和追兵马匹动画均采用缓存图像，以减少每帧绘制开销。
河西阿站在亚瑟左侧，约翰马斯顿站在右侧。亚瑟开火时，两位伙伴每 0.225 秒协同开火，每发伤害 35，瞄准亚瑟鼠标指向的同一位置；松开左键则停止开火。伙伴不独立选择目标。
第三关追兵移动速度从 85+2×波次降低为 45+波次（波次计入上限 40），约减半。每波开始将亚瑟恢复为 100/100 HP，适用于前 20 波和后续无尽模式。
测试覆盖伙伴左右站位、三路子弹瞄准同一点、每波恢复满血、减速追兵，以及原有关卡功能。
最终 2880×1753 隐藏窗口、20 名骑马追兵、三人射击压力测试：平均 47.3 FPS，最低一秒 45.6 FPS；实际游玩以 F3 显示为准。
默认安装位置：D:\dev\ArthurFrontier。

第三关的所有骑马追兵现在显示为“平克顿侦探”，包括战场名称、剧情说明与通关提示。
