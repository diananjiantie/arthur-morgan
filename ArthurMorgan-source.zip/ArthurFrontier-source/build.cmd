@echo off
setlocal
pushd "%~dp0"
if not exist bin mkdir bin
set "ARTHUR_CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%ARTHUR_CSC%" set "ARTHUR_CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
"%ARTHUR_CSC%" @build.rsp
set "ARTHUR_RESULT=%ERRORLEVEL%"
if "%ARTHUR_RESULT%"=="0" echo Built bin\ArthurFrontier.exe
popd
exit /b %ARTHUR_RESULT%
