using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Media;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
namespace ArthurFrontier {
    class Body {
        public float X,Y,R=16,HP=100,MaxHP=100,Angle,Step,Speed,Shoot,Hit;
        public bool Elite,Variant;
    }
    class Bullet {
        public float X,Y,VX,VY,Life,Damage,LastX,LastY;
        public bool Friendly;
    }
    class Particle {
        public float X,Y,VX,VY,Life,MaxLife,Size;
        public Color Color;
    }
    class Pickup {
        public float X,Y,Life=25;
    }
    class Corpse {
        public float X,Y,Life=12;
    }
    class Building {
        public float X,Y,W,H;
        public string Kind,Label;
        public Building(float x,float y,float w,float h,string kind,string label) {
            X=x;
            Y=y;
            W=w;
            H=h;
            Kind=kind;
            Label=label;
        }
    }
    class DrawItem {
        public float Depth;
        public Action Draw;
        public DrawItem(float depth,Action draw) {
            Depth=depth;
            Draw=draw;
        }
    }
    class BuildingSprite : IDisposable {
        public Bitmap Normal,Faded;
        public float X,Y;
        public void Dispose() {
            Normal.Dispose();
            Faded.Dispose();
        }
    }
}
