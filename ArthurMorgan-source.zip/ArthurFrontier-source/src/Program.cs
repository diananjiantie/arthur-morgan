using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Media;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
namespace ArthurFrontier {
    static class Program {
        [STAThread] static void Main(string[] args) {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            if(args.Length > 0 && args[0] == "--self-test") {
                SelfTest.Run(args.Length > 1 ? args[1] : AppDomain.CurrentDomain.BaseDirectory);
                return;
            }
            if(args.Length > 0 && args[0] == "--frame-test") {
                FrameProbe.Run(args.Length > 1 ? args[1] : AppDomain.CurrentDomain.BaseDirectory,args.Length > 2 && args[2]=="retina" ? 2880 : 1280,args.Length > 2 && args[2]=="retina" ? 1800 : 800);
                return;
            }
            Application.Run(new FrontierWindow());
        }
    }
}
