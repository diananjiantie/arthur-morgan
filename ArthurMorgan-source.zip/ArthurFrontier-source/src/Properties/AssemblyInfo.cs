using System.Reflection;
[assembly: AssemblyTitle("亚瑟 · 荒野死神")]
[assembly: AssemblyDescription("独立桌面西部小游戏：骑马、五波生存战与无限死眼")]
[assembly: AssemblyProduct("Arthur Frontier")]
[assembly: AssemblyVersion("8.0.0.0")]
[assembly: AssemblyFileVersion("8.0.0.0")]
