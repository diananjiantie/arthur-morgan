using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Media;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
namespace ArthurFrontier {
    sealed class GameRenderer : IDisposable {
        readonly Graphics graphics;
        readonly IntPtr sourceDC,bitmapHandle,oldBitmap;
        public readonly IntPtr Pixels;
        public double LastFrameMs;
        [StructLayout(LayoutKind.Sequential)] struct BitmapHeader {
            public uint Size;
            public int Width,Height;
            public ushort Planes,BitCount;
            public uint Compression,SizeImage;
            public int XPels,YPels;
            public uint ColorsUsed,ColorsImportant;
        }
        [DllImport("gdi32.dll")] static extern IntPtr CreateCompatibleDC(IntPtr dc);
        [DllImport("gdi32.dll")] static extern IntPtr CreateDIBSection(IntPtr dc,ref BitmapHeader info,uint usage,out IntPtr bits,IntPtr section,uint offset);
        [DllImport("gdi32.dll")] static extern IntPtr SelectObject(IntPtr dc,IntPtr obj);
        [DllImport("gdi32.dll")] static extern bool DeleteObject(IntPtr obj);
        [DllImport("gdi32.dll")] static extern bool DeleteDC(IntPtr dc);
        [DllImport("gdi32.dll")] static extern bool StretchBlt(IntPtr dest,int x,int y,int w,int h,IntPtr src,int sx,int sy,int sw,int sh,uint operation);
        [DllImport("gdi32.dll")] static extern int SetStretchBltMode(IntPtr dc,int mode);
        public GameRenderer() {
            sourceDC=CreateCompatibleDC(IntPtr.Zero);
            BitmapHeader header=new BitmapHeader {
                Size=40,Width=1280,Height=-800,Planes=1,BitCount=32,SizeImage=1280*800*4
            };
            IntPtr pixels;
            bitmapHandle=CreateDIBSection(sourceDC,ref header,0,out pixels,IntPtr.Zero,0);
            Pixels=pixels;
            if(sourceDC==IntPtr.Zero||bitmapHandle==IntPtr.Zero) {
                if(bitmapHandle!=IntPtr.Zero)DeleteObject(bitmapHandle);
                if(sourceDC!=IntPtr.Zero)DeleteDC(sourceDC);
                throw new InvalidOperationException("Cannot allocate game back buffer");
            }
            oldBitmap=SelectObject(sourceDC,bitmapHandle);
            graphics=Graphics.FromHdc(sourceDC);
            graphics.CompositingQuality=CompositingQuality.HighSpeed;
            graphics.InterpolationMode=InterpolationMode.NearestNeighbor;
        }
        public void RenderFrame(FrontierGame game) {
            graphics.ResetTransform();
            game.Render(graphics);
            graphics.Flush(FlushIntention.Sync);
        }
        public void Draw(FrontierGame game,Graphics target,int width,int height) {
            Stopwatch timing=Stopwatch.StartNew();
            RenderFrame(game);
            float scale=Math.Min(width/1280f,height/800f);
            int w=(int)(1280*scale),h=(int)(800*scale),x=(width-w)/2,y=(height-h)/2;
            if(x>0) {
                target.FillRectangle(Brushes.Black,0,0,x,height);
                target.FillRectangle(Brushes.Black,x+w,0,width-x-w,height);
            }
            if(y>0) {
                target.FillRectangle(Brushes.Black,0,0,width,y);
                target.FillRectangle(Brushes.Black,0,y+h,width,height-y-h);
            }
            // Present one bounded 1280x800 frame. Fullscreen never multiplies world rendering work.
            graphics.Flush(FlushIntention.Sync);
            IntPtr destDC=IntPtr.Zero;
            try {
                destDC=target.GetHdc();
                SetStretchBltMode(destDC,3);
                if(!StretchBlt(destDC,x,y,w,h,sourceDC,0,0,1280,800,0x00CC0020))throw new InvalidOperationException("Frame presentation failed");
            }
            finally {
                if(destDC!=IntPtr.Zero)target.ReleaseHdc(destDC);
            }
            LastFrameMs=timing.Elapsed.TotalMilliseconds;
        }
        public void Dispose() {
            graphics.Dispose();
            SelectObject(sourceDC,oldBitmap);
            DeleteObject(bitmapHandle);
            DeleteDC(sourceDC);
        }
    }
}
