using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Media;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
namespace ArthurFrontier {
    static class SelfTest {
        static readonly List<string> passed=new List<string>();
        static void Check(bool value,string name) {
            if(!value)throw new Exception(name);
            passed.Add(name);
        }
        static void Release(FrontierGame game,Keys key) {
            game.KeysDown.Remove(key);
        }
        static void SaveFrame(FrontierGame game,string path) {
            using(Bitmap bmp=new Bitmap(1280,800))using(Graphics g=Graphics.FromImage(bmp))using(GameRenderer renderer=new GameRenderer()) {
                renderer.Draw(game,g,1280,800);
                bmp.Save(path,System.Drawing.Imaging.ImageFormat.Png);
            }
        }
        public static void Run(string output) {
            Directory.CreateDirectory(output);
            try {
                using(FrontierGame game=new FrontierGame()) {
                    game.Muted=true;
                    game.SettingsPath=Path.Combine(output,"test-controls.txt");
                    game.SetSensitivity(.5f);
                    game.Mouse=new PointF(640,400);game.MoveAim(100,0);
                    Check(game.Mouse.X==690,"Low sensitivity scales relative mouse movement");
                    game.SetSensitivity(2f);
                    game.Mouse=new PointF(640,400);game.MoveAim(100,0);
                    Check(game.Mouse.X==840,"High sensitivity scales relative mouse movement");
                    Check(File.ReadAllText(game.SettingsPath)=="2","Sensitivity setting is saved");
                    game.SetSensitivity(1f);
                    game.Click(500,610);
                    Check(game.ShowCredits,"About credits opens below level selection");
                    SaveFrame(game,Path.Combine(output,"credits.png"));
                    game.Click(640,625);
                    Check(!game.ShowCredits,"Credits return button closes overlay");
                    SaveFrame(game,Path.Combine(output,"intro.png"));
                    game.Start();
                    Check(game.Mounted&&game.Chapter=="ride","Opening horseback chapter");
                    game.Enemies.Clear();
                    game.KeysDown.Add(Keys.D);
                    float x=game.Player.X;
                    game.Update(.1f);
                    Check(game.Player.X>x+40,"Horse movement speed");
                    game.KeysDown.Clear();
                    game.KeyPressed(Keys.E);
                    Release(game,Keys.E);
                    for(int i=0;i<2000;i++)game.Update(.033f);
                    Check(game.DeadEye,"Dead Eye remains active after 66 seconds without resource");
                    game.KeyPressed(Keys.E);
                    Release(game,Keys.E);
                    Check(!game.DeadEye,"E toggles Dead Eye off");
                    game.KeyPressed(Keys.E);
                    game.KeyPressed(Keys.E);
                    Check(game.DeadEye,"Holding E does not repeatedly toggle");
                    Release(game,Keys.E);
                    game.KeyPressed(Keys.E);
                    Release(game,Keys.E);
                    game.Ammo=0;
                    game.Cooldown=0;
                    game.Fire();
                    Check(game.ReloadTime==0,"Empty gun does not auto reload");
                    game.KeyPressed(Keys.R);
                    Release(game,Keys.R);
                    for(int i=0;i<55;i++)game.Update(.033f);
                    Check(game.Ammo==8,"R reloads eight rifle rounds");
                    SaveFrame(game,Path.Combine(output,"horseback.png"));
                    foreach(PointF target in new[] {
                        new PointF(650,730),new PointF(950,575),new PointF(1130,750)
                    }) {
                        game.Player.X=target.X;
                        game.Player.Y=target.Y;
                        game.Update(.016f);
                    }
                    Check(game.Chapter=="town"&&game.Checkpoint==3,"All riding checkpoints reach town");
                    game.ToggleHorse();
                    Check(!game.Mounted,"F dismounts in town");
                    game.ToggleHorse();
                    Check(game.Mounted,"F remounts near horse");
                    game.ToggleHorse();
                    game.Player.X=240;
                    game.Player.Y=320;
                    game.Move(game.Player,40,0);
                    Check(game.Player.X==240,"Building collision");
                    game.Player.X=1000;
                    game.Player.Y=750;
                    game.CameraX=1000;
                    game.CameraY=750;
                    game.Enemies.Clear();
                    game.SpawnQueue=0;
                    game.Wave=1;
                    game.Bullets.Clear();
                    game.Cooldown=0;
                    game.Ammo=6;
                    game.ReloadTime=0;
                    game.Enemies.Add(new Body {
                        X=1100,Y=750,HP=40,MaxHP=40,Shoot=99
                    });
                    game.Mouse=game.Project(1100,750,22);
                    int kills=game.Kills;
                    game.Fire();
                    for(int i=0;i<10;i++)game.Update(.016f);
                    Check(game.Kills==kills+1,"Projected mouse aim hits enemy");
                    foreach(PointF p in new[] {
                        new PointF(200,300),new PointF(950,710),new PointF(1500,1100)
                    }) {
                        PointF s=game.Project(p.X,p.Y,43),w=game.Unproject(s.X,s.Y,43);
                        Check(Math.Abs(w.X-p.X)<.001&&Math.Abs(w.Y-p.Y)<.001,"Mounted aim projection round trip");
                    }
                    game.SwitchWeapon(WeaponType.Revolver);
                    Check(game.Capacity==6,"Revolver remains available with six rounds");
                    game.SwitchWeapon(WeaponType.Rifle);
                    Check(game.Capacity==8,"Rifle has eight-round magazine");
                    foreach(bool eye in new[] {
                        false,true
                    }) {
                        game.Enemies.Clear();
                        game.Bullets.Clear();
                        game.Wave=1;
                        game.SpawnQueue=0;
                        game.Player.X=1000;
                        game.Player.Y=750;
                        game.CameraX=1000;
                        game.CameraY=750;
                        game.DeadEye=eye;
                        game.Ammo=8;
                        game.Cooldown=0;
                        game.ReloadTime=0;
                        game.Enemies.Add(new Body {
                            X=1110,Y=750,HP=80,MaxHP=80,Speed=0,Shoot=999
                        });
                        game.Mouse=game.Project(1110,750,22);
                        int before=game.Kills;
                        game.Fire();
                        for(int i=0;i<12;i++)game.Update(.01f);
                        Check(game.Kills==before+1,"Rifle one-shots normal enemy; DeadEye="+eye);
                        Body boss=new Body {
                            X=1110,Y=750,HP=WeaponRules.BossHealth,MaxHP=WeaponRules.BossHealth,Elite=true,Speed=0,Shoot=999
                        };
                        game.Enemies.Clear();
                        game.Enemies.Add(boss);
                        game.Bullets.Clear();
                        game.Ammo=8;
                        for(int shot=1;shot<=10;shot++) {
                            if(game.Ammo==0) {
                                Check(shot==9,"Boss fight requires reload after eight rifle shots");
                                game.Reload();
                                for(int i=0;i<110;i++)game.Update(1f/60);
                            }
                            game.Cooldown=0;
                            game.Fire();
                            for(int i=0;i<12;i++)game.Update(.01f);
                            Check(shot<10?boss.HP==1000-shot*100&&game.Enemies.Contains(boss):boss.HP<=0&&!game.Enemies.Contains(boss),"Boss rifle hit "+shot+"; DeadEye="+eye);
                        }
                    }
                    game.DeadEye=false;
                    game.Invulnerable=0;
                    game.Player.HP=100;
                    game.Damage(14);
                    game.Damage(14);
                    Check(game.Player.HP==86,"Damage invulnerability");
                    game.TogglePause();
                    float elapsed=game.Elapsed;
                    game.Update(1);
                    Check(game.Elapsed==elapsed,"Pause freezes simulation");
                    game.TogglePause();
                    game.Enemies.Clear();
                    game.SpawnQueue=0;
                    game.Wave=0;
                    for(int i=0;i<250;i++)game.Update(.016f);
                    Check(game.Wave==1&&game.Enemies.Count>0,"Town wave spawns");
                    game.DeadEye=true;
                    SaveFrame(game,Path.Combine(output,"deadeye.png"));
                    game.DeadEye=false;
                    SaveFrame(game,Path.Combine(output,"town.png"));
                    game.Enemies.Clear();
                    game.SpawnQueue=0;
                    game.Wave=5;
                    game.Update(.016f);
                    Check(game.State=="won","Fifth wave victory");
                    game.Start();
                    game.Invulnerable=0;
                    game.Damage(100);
                    Check(game.State=="lost","Death state");
                    game.Start();
                    Check(game.State=="playing"&&game.Mounted&&!game.DeadEye,"Restart resets chapter and toggles");
                    game.Finish(true);
                    game.ContinueGame();
                    Check(game.Level==2&&game.Chapter=="town"&&game.Wave==0,"First victory continues to level two");
                    Check(game.NormalHealth==160&&game.BossHealth==1600,"Micah has exactly ten times normal HP");
                    Check(game.Buildings[0].Label=="RAIL DEPOT"&&!game.Blocked(1050,750,21),"Distinct mine map and clear spawn");
                    game.SwitchWeapon(WeaponType.Revolver);
                    game.Cooldown=0;
                    game.Fire();
                    Check(game.Cooldown==.14f,"Level two faster revolver");
                    game.Enemies.Clear();
                    game.Bullets.Clear();
                    game.Wave=5;
                    game.SpawnQueue=1;
                    game.Update(.016f);
                    Check(game.ActiveBoss!=null&&game.ActiveBoss.HP==1600,"Final wave spawns Micah");
                    game.ActiveBoss.X=1160;
                    game.ActiveBoss.Y=750;
                    game.ActiveBoss.Speed=0;
                    game.ActiveBoss.Shoot=999;
                    game.Mounted=false;
                    game.Player.R=16;
                    game.SwitchWeapon(WeaponType.Rifle);
                    game.Mouse=game.Project(1160,750,22);
                    Body micah=game.ActiveBoss;
                    game.Ammo=8;
                    for(int shot=1;shot<=16;shot++) {
                        if(game.Ammo==0) {
                            game.Reload();
                            for(int t=0;t<110;t++)game.Update(1f/60);
                        }
                        game.Cooldown=0;
                        game.Fire();
                        for(int t=0;t<12;t++)game.Update(.01f);
                        Check(micah.HP==1600-shot*100,"Micah live health after rifle hit "+shot);
                        if(shot==7)SaveFrame(game,Path.Combine(output,"level2-boss.png"));
                    }
                    Check(!game.Enemies.Contains(micah)&&game.ActiveBoss.HP==0,"Micah defeated with zero remaining health");
                    game.Finish(false);
                    game.ContinueGame();
                    Check(game.Level==2&&game.Player.HP==100&&game.ActiveBoss==null,"Death retries second level cleanly");
                    game.Enemies.Clear();
                    game.Wave=5;
                    game.SpawnQueue=0;
                    game.Update(.016f);
                    Check(game.State=="won"&&game.Level==2,"Second level final victory");
                    game.ContinueGame();
                    Check(game.Level==3&&game.Chapter=="train","Second victory advances to train level");
                    game.StartSecondLevel();
                    game.Muted=true;
                    game.Invulnerable=999;
                    game.Enemies.Clear();
                    game.UpdateWorldEvents(14.9f);
                    Check(game.TrainCount==0,"No early train");
                    game.UpdateWorldEvents(.1f);
                    Check(game.TrainCount==1&&game.TrainActive,"Train arrives at 15 seconds");
                    for(int i=0;i<150;i++)game.UpdateWorldEvents(.1f);
                    Check(game.TrainCount==2,"Train repeats every 15 seconds");
                    game.TrainY=800;
                    SaveFrame(game,Path.Combine(output,"train.png"));
                    game.DamageHorse(80);
                    Check(game.HorseHP==120,"Horse has independent health");
                    game.HorseInvulnerable=0;
                    game.DamageHorse(200);
                    Check(game.HorseHP==0&&!game.Mounted,"Horse death forces dismount");
                    game.ToggleHorse();
                    Check(!game.Mounted,"Dead horse cannot be mounted");
                    game.ActiveBoss=new Body {
                        HP=800,MaxHP=1600,Elite=true
                    };
                    game.BossQuiet=0;
                    game.UpdateWorldEvents(4);
                    Check(game.ActiveBoss.HP==800,"Boss regeneration delay");
                    game.UpdateWorldEvents(2);
                    Check(game.ActiveBoss.HP>800,"Boss heals after quiet period");
                    game.ActiveBoss.HP=1599;
                    game.UpdateWorldEvents(1);
                    Check(game.ActiveBoss.HP==1600,"Boss regeneration capped");
                    game.ActiveBoss.HP=0;
                    game.UpdateWorldEvents(1);
                    Check(game.ActiveBoss.HP==0,"Dead boss cannot regenerate");
                    game.Paused=true;
                    float clock=game.TrainClock;
                    game.Update(1);
                    Check(game.TrainClock==clock,"Pause freezes train timer");
                    game.StartSecondLevel();
                    Check(game.HorseHP==200&&game.TrainCount==0&&game.BossQuiet==0,"Retry resets world events");
                }
                using(FrontierGame game=new FrontierGame()) {
                    game.Muted=true;
                    game.Home();
                    game.KeyPressed(Keys.D3);
                    game.KeysDown.Clear();
                    game.KeyPressed(Keys.Enter);
                    game.KeysDown.Clear();
                    Check(game.Level==3&&!game.Mounted&&game.Buildings.Count==0,"Home keyboard selects third level");
                    game.Invulnerable=999;
                    game.Enemies.Clear();
                    game.StartWave();
                    Check(game.Wave==1&&game.SpawnQueue==6,"Train first wave");
                    game.Player.HP=15;
                    game.Wave=0;
                    game.StartWave();
                    Check(game.Player.HP==100,"Every third-level wave restores full health");
                    game.Update(.016f);
                    Check(game.Enemies.Count==1&&game.Enemies[0].Y>game.Player.Y,"Pursuers spawn behind train");
                    Check(game.Enemies[0].Speed==46,"Pursuers move more slowly");
                    game.Enemies.Clear();
                    game.SpawnQueue=0;
                    game.Wave=1;
                    game.Cooldown=0;
                    int ammo=game.Ammo;
                    game.Mouse=game.Project(945,1000,22);
                    game.Bullets.Clear();
                    game.AllyCooldown=0;
                    game.Fire();
                    Check(game.Cooldown==.075f&&game.Ammo==ammo,"Machine gun fast unlimited ammunition");
                    Check(game.Bullets.Count==3,"Both companions fire with Arthur");
                    foreach(Bullet bullet in game.Bullets) {
                        float cross=(945-bullet.X)*bullet.VY-(1000-bullet.Y)*bullet.VX;
                        Check(Math.Abs(cross)<100,"All three shots converge at player aim");
                    }
                    Check(game.AllyPosition(-1).X<game.Player.X&&game.AllyPosition(1).X>game.Player.X,"Companions flank Arthur");
                    game.Enemies.Add(new Body {
                        X=945,Y=1000,HP=100,MaxHP=100,Speed=0,Shoot=999
                    });
                    for(int i=0;i<2;i++) {
                        game.Cooldown=0;
                        game.Fire();
                        for(int t=0;t<25;t++)game.Update(.01f);
                    }
                    Check(game.Kills>0,"Machine gun bullets hit pursuers");
                    game.KeysDown.Add(Keys.D);
                    float x=game.Player.X;
                    game.Update(.1f);
                    Check(game.Player.X==x,"Gunner remains at turret");
                    game.KeysDown.Clear();
                    for(int wave=1;wave<=20;wave++) {
                        game.Wave=wave;
                        game.Enemies.Clear();
                        game.SpawnQueue=0;
                        game.Update(.016f);
                        if(wave<20)Check(game.State=="playing","Train survives wave "+wave);
                    }
                    Check(game.State=="won","Twenty waves completes challenge");
                    game.ContinueGame();
                    Check(game.Endless&&game.State=="playing","Continue into endless mode");
                    game.StartWave();
                    Check(game.Wave==21,"Endless wave 21");
                    game.Invulnerable=0;
                    game.Enemies.Clear();
                    game.SpawnQueue=10;
                    for(int i=0;i<5;i++)game.Update(.51f);
                    SaveFrame(game,Path.Combine(output,"third-level.png"));
                    game.Finish(false);
                    game.ContinueGame();
                    Check(game.Level==3&&game.Wave==0&&!game.Endless,"Third level retry resets challenge");
                    game.Home();
                    game.Click(game.LevelButton(2).X+10,510);
                    game.Click(game.MainButton.X+10,600);
                    Check(game.Level==2,"Home mouse selects level two");
                    game.Home();
                    SaveFrame(game,Path.Combine(output,"level-select.png"));
                    game.Finish(true);
                    SaveFrame(game,Path.Combine(output,"victory-credits.png"));
                }
                using(FrontierWindow window=new FrontierWindow()) {
                    window.Game.Muted=true;
                    IntPtr handle=window.Handle;
                    using(Bitmap frame=new Bitmap(1280,800)) {
                        window.DrawToBitmap(frame,new Rectangle(0,0,1280,800));
                    }
                    Check(handle!=IntPtr.Zero,"Native WinForms window creates and paints");
                }
                File.WriteAllText(Path.Combine(output,"self-test.txt"),"PASS\r\n"+string.Join("\r\n",passed.ToArray()),Encoding.UTF8);
            }
            catch(Exception e) {
                File.WriteAllText(Path.Combine(output,"self-test.txt"),"FAIL\r\n"+e,Encoding.UTF8);
                Environment.ExitCode=1;
            }
        }
    }
}
