# 亚瑟摩根 · 安卓版

离线运行的横屏 Android 游戏。游戏和触屏界面保存在 APK 内，使用系统 Android WebView 绘制，无需打开浏览器，不申请联网、存储、相机或麦克风权限。最低 Android 8.0，建议更新 Android System WebView。

左摇杆移动，右摇杆拖动瞄准并持续射击（松开停止）；屏幕中间按钮用于换弹、无限死眼、切枪、上下马和冲刺。支持两个手指同时操作。第三关固定机枪位，伙伴向同一位置射击。主页可直接选择三关。

保留三关主要规则：第一关骑马进镇与五波战斗、第二关 160 血小怪 / 1600 血麦卡与每 15 秒列车、第三关 20 波后继续无尽模式。平克顿侦探减速，河西阿在左、约翰马斯顿在右，每波满血。Boss 五秒未受伤后每秒恢复 2%，马匹有独立 200 血量。

这是从 Windows C# 版本移植的手机版本，使用适合触屏的 UI 和绘制实现。

## 构建

准备 Windows x64 JDK 17、Android SDK Build Tools 35.0.0、Android 35 Platform。运行：

```powershell
./build.ps1 -Jdk 'C:\path\jdk-17' -BuildTools 'C:\path\build-tools\35.0.0' -Platform 'C:\path\platforms\android-35'
```

输出 `build/ArthurMorgan.apk`。首次生成独立签名密钥，保存在 `private-signing/`；不要上传或共享密钥及密码。后续更新必须使用同一签名密钥。公开源码包不含密钥。

规则测试：`node tests/core.test.cjs`。

## 验证范围

APK 应通过 apksigner 签名验证、zipalign 对齐和 manifest 校验。游戏规则和手机控制有自动化检查。未连接真实安卓手机时，不能据此声称所有手机已实测，帧率随设备变化。
