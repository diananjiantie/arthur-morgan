param([string]$Jdk,[string]$BuildTools,[string]$Platform,[string]$SigningDirectory)
$ErrorActionPreference='Stop'
if(-not $Jdk -or -not $BuildTools -or -not $Platform){throw 'Pass -Jdk, -BuildTools and -Platform (directory containing android.jar).'}
$projectDir=$PSScriptRoot
$buildDir=Join-Path $projectDir 'build'
New-Item -ItemType Directory -Path $buildDir,(Join-Path $buildDir 'classes'),(Join-Path $buildDir 'dex') -Force | Out-Null
if(-not $SigningDirectory){$SigningDirectory=Join-Path $projectDir 'private-signing'}
New-Item -ItemType Directory -Path $SigningDirectory -Force | Out-Null
function Run([string]$Executable,[string[]]$Arguments){& $Executable @Arguments;if($LASTEXITCODE -ne 0){throw "Build failed: $Executable (exit $LASTEXITCODE)"}}
$java=Join-Path $Jdk 'bin\java.exe'
$platformJar=Join-Path $Platform 'android.jar'
Run (Join-Path $BuildTools 'aapt2.exe') @('compile','--dir',(Join-Path $projectDir 'res'),'-o',(Join-Path $buildDir 'resources.zip'))
Run (Join-Path $BuildTools 'aapt2.exe') @('link','-o',(Join-Path $buildDir 'unsigned.apk'),'-I',$platformJar,'--manifest',(Join-Path $projectDir 'AndroidManifest.xml'),'-A',(Join-Path $projectDir 'assets'),(Join-Path $buildDir 'resources.zip'))
Run (Join-Path $Jdk 'bin\javac.exe') @('-encoding','UTF-8','-source','8','-target','8','-bootclasspath',$platformJar,'-d',(Join-Path $buildDir 'classes'),(Join-Path $projectDir 'src\com\arthur\frontier\MainActivity.java'))
Run (Join-Path $Jdk 'bin\jar.exe') @('cf',(Join-Path $buildDir 'classes.jar'),'-C',(Join-Path $buildDir 'classes'),'.')
Run $java @('-cp',(Join-Path $BuildTools 'lib\d8.jar'),'com.android.tools.r8.D8','--min-api','26','--lib',$platformJar,'--output',(Join-Path $buildDir 'dex'),(Join-Path $buildDir 'classes.jar'))
Push-Location (Join-Path $buildDir 'dex')
try{Run (Join-Path $BuildTools 'aapt.exe') @('add',(Join-Path $buildDir 'unsigned.apk'),'classes.dex')}finally{Pop-Location}
Run (Join-Path $BuildTools 'zipalign.exe') @('-f','-p','4',(Join-Path $buildDir 'unsigned.apk'),(Join-Path $buildDir 'aligned.apk'))
$key=Join-Path $SigningDirectory 'arthur-mobile.p12'
$passwordFile=Join-Path $SigningDirectory 'password.txt'
if(-not(Test-Path -LiteralPath $key)){
    if(Test-Path -LiteralPath $passwordFile){throw 'Signing password exists without key. Restore key or choose a new signing directory.'}
    $bytes=New-Object byte[] 32
    $rng=[Security.Cryptography.RandomNumberGenerator]::Create();$rng.GetBytes($bytes);$rng.Dispose()
    [IO.File]::WriteAllText($passwordFile,[Convert]::ToBase64String($bytes))
    $env:ARTHUR_SIGN_PASS=[IO.File]::ReadAllText($passwordFile)
    try{Run (Join-Path $Jdk 'bin\keytool.exe') @('-genkeypair','-keystore',$key,'-storetype','PKCS12','-storepass:env','ARTHUR_SIGN_PASS','-alias','arthur','-keyalg','RSA','-keysize','2048','-validity','10000','-dname','CN=Arthur Morgan Offline Game')}finally{Remove-Item Env:\ARTHUR_SIGN_PASS}
}
Run $java @('-jar',(Join-Path $BuildTools 'lib\apksigner.jar'),'sign','--ks',$key,'--ks-pass',('file:'+$passwordFile),'--ks-key-alias','arthur','--out',(Join-Path $buildDir 'ArthurMorgan.apk'),(Join-Path $buildDir 'aligned.apk'))
Run $java @('-jar',(Join-Path $BuildTools 'lib\apksigner.jar'),'verify','--verbose','--print-certs',(Join-Path $buildDir 'ArthurMorgan.apk'))
Run (Join-Path $BuildTools 'aapt.exe') @('dump','badging',(Join-Path $buildDir 'ArthurMorgan.apk'))
