package com.arthur.frontier;

import android.app.Activity;
import android.os.Bundle;
import android.media.AudioManager;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import java.io.ByteArrayInputStream;

/** Offline-only packaged game. No network/storage/phone permissions or JS bridges. */
public final class MainActivity extends Activity {
    private WebView web;
    private void fullscreen() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setVolumeControlStream(AudioManager.STREAM_MUSIC);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        fullscreen(); web = new WebView(this); setContentView(web);
        web.setBackgroundColor(0xff172321);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(false);
        web.getSettings().setSupportZoom(false);
        web.getSettings().setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return true; }
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                String path=r.getUrl().getPath();
                if("https".equals(r.getUrl().getScheme()) && "appassets.androidplatform.net".equals(r.getUrl().getHost()) && path!=null && path.matches("/[a-zA-Z0-9._-]+")) {
                    try { String mime=path.endsWith(".js")?"application/javascript":path.endsWith(".css")?"text/css":"text/html";
                        return new WebResourceResponse(mime,"UTF-8",getAssets().open(path.substring(1)));
                    } catch(Exception ignored) { }
                }
                return new WebResourceResponse("text/plain","UTF-8",new ByteArrayInputStream(new byte[0]));
            }
        });
        web.loadUrl("https://appassets.androidplatform.net/index.html");
    }
    @Override protected void onPause() { if(web!=null){web.evaluateJavascript("window.pauseGame && window.pauseGame()",null);web.onPause();}super.onPause(); }
    @Override protected void onResume() { super.onResume();if(web!=null)web.onResume();fullscreen(); }
    @Override public void onWindowFocusChanged(boolean focused) { super.onWindowFocusChanged(focused);if(focused)fullscreen(); }
    @Override public void onBackPressed() { web.evaluateJavascript("window.backGame && window.backGame()",null); }
    @Override protected void onDestroy() { if(web!=null){web.stopLoading();web.destroy();web=null;}super.onDestroy(); }
}
