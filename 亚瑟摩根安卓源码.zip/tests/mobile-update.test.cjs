const assert=require('node:assert/strict'),{Game}=require('../assets/core.js');
function turn(sensitivity,dt){let g=new Game();g.start(3);g.player.angle=0;for(let t=0;t<.05-.000001;t+=dt)g.update(dt,{ax:0,ay:1,sensitivity});return g.player.angle;}
assert(turn(2,.01)>turn(.5,.01));
assert(Math.abs(turn(1,.01)-turn(1,.025))<.00001);
let g=new Game(),events=[];g.onEvent=e=>events.push(e);g.start(2);g.fire({x:1300,y:750});g.action('reload');g.action('eye');g.damage(10);g.finish(true);
for(let e of ['shot','reload','eye','hit','won'])assert(events.includes(e),e);
console.log('PASS sensitivity changes turn speed independent of FPS; gameplay sound events');
